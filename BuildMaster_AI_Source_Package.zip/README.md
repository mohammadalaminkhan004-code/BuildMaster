# BuildMaster AI Demo

An interactive Flutter source-code demo for Android, iOS and Web.

## Run
1. Install Flutter SDK.
2. In this folder run `flutter pub get`.
3. Run `flutter run` (choose Android, iOS simulator, or Chrome).

## Included
- Dashboard and navigation
- Concrete volume calculator (m³ and CFT)
- Unit converter
- Project create/list (in-memory demo data)
- Camera mapping preview with reference-point counter (simulated)
- 1–3 floor 2D/3D massing preview (illustrative)
- Cost estimate using an illustrative rate
- Reports preview placeholder
- Language selector with 15 language choices; current UI translations are complete for English, Bengali and Hindi, with fallback English for other languages.

## Important limitations
This is a source-code demo, not a compiled APK/IPA and not a production engineering application.
Camera mapping is simulated and is not a land survey. 2D/3D screens are illustrative previews, not construction drawings. Cost rates are examples. Structural design and all construction decisions require local code compliance, soil data, and review by qualified professionals.
