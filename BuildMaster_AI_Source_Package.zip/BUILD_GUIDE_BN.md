# BuildMaster AI — Build Guide (বাংলা)

## এই প্যাকেজে কী আছে
এটি Android, iOS ও Windows-এর জন্য Flutter source-code demo। Dashboard, project list, concrete volume calculator, unit converter, cost estimate preview, illustrative 2D/3D concept, camera-mapping preview এবং language selector আছে।

## চালানোর নিয়ম
1. Flutter SDK ও Android Studio ইনস্টল করুন।
2. টার্মিনালে এই ফোল্ডারে গিয়ে `flutter pub get` চালান।
3. Android: `flutter run -d android`
4. Windows: Windows PC-তে Visual Studio-এর Desktop development with C++ workload ইনস্টল করে `flutter run -d windows`।
5. iOS: macOS ও Xcode প্রয়োজন; `flutter run -d ios`।

## APK বানানো
`flutter build apk --release`
ফাইল পাওয়া যাবে: `build/app/outputs/flutter-apk/app-release.apk`

## Windows build
`flutter build windows --release`

## iOS build
macOS/Xcode-এ `flutter build ipa --release`। iOS build Windows-এ করা যায় না।

## গুরুত্বপূর্ণ
এই পরিবেশে Flutter SDK/Android build toolchain নেই, তাই এখানে APK/IPA/EXE compile করা হয়নি। এটি সম্পাদনাযোগ্য source project, ইনস্টলযোগ্য অ্যাপ নয়।

## নিরাপত্তা ও প্রকৌশল সীমা
- AI API key কখনো Flutter app-এর মধ্যে রাখবেন না; secure backend-এ রাখুন।
- Camera mapping screen এখন simulated preview; এটি cadastral/legal survey নয়।
- 2D/3D floor plan illustrative concept; অনুমোদিত construction drawing নয়।
- Cost rate উদাহরণমাত্র; স্থানীয় বাজারদর দিয়ে বদলাতে হবে।
- Structural design, foundation, beam/column/rebar এবং construction approval-এর জন্য স্থানীয় code, soil data ও qualified engineer review আবশ্যক।
