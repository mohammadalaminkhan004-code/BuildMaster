# Architecture notes

- Flutter / Dart single codebase for Android, iOS and Web.
- `MaterialApp` locale is controlled from Settings.
- Language choices are provided for 15 locales. The demo contains full core-screen translations for Bengali, English and Hindi; other locales currently fall back to English. Production requires reviewed ARB translation files for every supported locale, including technical terminology and RTL QA.
- Feature screens are separated into calculator, converter, project, mapping, design, estimate and report pages.

## Production next steps
1. Add ARB localization + professional translation for all target languages.
2. Persist projects with SQLite/Drift or Isar and add user accounts/cloud sync.
3. Implement camera capture, calibration, manual boundary points and uncertainty display.
4. Add proper 2D CAD-like editor and 3D engine; export reviewed drawings to PDF.
5. Build material database, regional rates, taxes and estimate assumptions.
6. Add subscription/payments, privacy/security, automated tests and app-store packaging.
