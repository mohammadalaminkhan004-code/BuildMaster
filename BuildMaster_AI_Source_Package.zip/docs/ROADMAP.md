# BuildMaster AI roadmap

## Demo included
Dashboard, calculators, converter, project list, language picker, simulated mapping, illustrative 1–3 floor preview, estimate sample and report placeholder.

## Production phases
- Phase 1: persistence, authentication, project workspace, localization.
- Phase 2: validated quantity takeoff, cost database, PDF reports.
- Phase 3: camera-assisted measurement with calibration and uncertainty controls.
- Phase 4: 2D plan editor and 3D visualization.
- Phase 5: code-aware engineering workflows with professional review and regional compliance.

Never present camera estimates or AI-generated structural layouts as certified survey or construction approval.
