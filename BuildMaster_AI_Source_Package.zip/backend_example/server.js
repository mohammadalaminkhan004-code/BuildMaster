// Optional secure AI backend starter (Node.js 20+).
// Keep OPENAI_API_KEY on the server only. Never ship it in the mobile/desktop app.
import express from 'express';

const app = express();
app.use(express.json({ limit: '32kb' }));

app.post('/api/assistant', async (req, res) => {
  try {
    const question = String(req.body?.question ?? '').trim();
    if (!question || question.length > 4000) {
      return res.status(400).json({ error: 'Question is required (max 4000 chars).' });
    }
    if (!process.env.OPENAI_API_KEY) {
      return res.status(503).json({ error: 'AI service is not configured.' });
    }

    const response = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || 'gpt-5',
        input: [
          {
            role: 'system',
            content: 'You are BuildMaster AI, a construction learning and estimation assistant. Explain assumptions, use metric units by default, and never present preliminary calculations or concepts as certified structural designs. Direct users to qualified local engineers for safety-critical decisions.'
          },
          { role: 'user', content: question }
        ]
      })
    });
    const data = await response.json();
    if (!response.ok) return res.status(502).json({ error: 'AI provider request failed.' });
    const answer = (data.output || [])
      .flatMap(item => item.content || [])
      .filter(item => item.type === 'output_text')
      .map(item => item.text)
      .join('\n');
    return res.json({ answer });
  } catch {
    return res.status(500).json({ error: 'Internal server error.' });
  }
});

app.listen(process.env.PORT || 8080, () => {
  console.log(`BuildMaster AI backend listening on ${process.env.PORT || 8080}`);
});
