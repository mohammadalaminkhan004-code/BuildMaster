
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

void main() => runApp(const BuildMasterApp());

const languages = {
  'বাংলা': 'bn', 'English': 'en', 'العربية': 'ar', 'हिन्दी': 'hi',
  'اردو': 'ur', 'Español': 'es', 'Français': 'fr', '中文': 'zh',
  '日本語': 'ja', 'Deutsch': 'de', 'Türkçe': 'tr', 'Русский': 'ru',
  'Português': 'pt', 'Bahasa Indonesia': 'id', 'Italiano': 'it',
};

class BuildMasterApp extends StatefulWidget {
  const BuildMasterApp({super.key});
  @override
  State<BuildMasterApp> createState() => _BuildMasterAppState();
}

class _BuildMasterAppState extends State<BuildMasterApp> {
  String locale = 'en';
  void setLocale(String code) => setState(() => locale = code);
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'BuildMaster AI',
    locale: Locale(locale),
    supportedLocales: languages.values.map((e) => Locale(e)),
    localizationsDelegates: const [
      GlobalMaterialLocalizations.delegate,
      GlobalWidgetsLocalizations.delegate,
      GlobalCupertinoLocalizations.delegate,
    ],
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xff176b58)), useMaterial3: true),
    home: DemoShell(locale: locale, onLocale: setLocale),
  );
}

String tr(String code, String key) {
  final map = <String, Map<String, String>>{
    'en': {'home':'Home','projects':'Projects','tools':'Tools','reports':'Reports','settings':'Settings','welcome':'Build smarter with AI','quick':'Quick tools','newProject':'New project','calculator':'Concrete calculator','converter':'Unit converter','land':'Land mapper demo','design':'House design studio','estimate':'Cost estimate','language':'App language','save':'Save','length':'Length (m)','width':'Width (m)','thickness':'Thickness (m)','calculate':'Calculate','result':'Result','name':'Project name','create':'Create project','noProjects':'No projects yet','demo':'DEMO PREVIEW','notice':'Preliminary demo only. Verify all measurements and structural designs with a qualified engineer.','floors':'Number of floors','generate':'Preview design','mapping':'Camera mapping preview','capture':'Capture reference point','report':'Project report','total':'Estimated total','materials':'Material summary','area':'Area','volume':'Volume'},
    'bn': {'home':'হোম','projects':'প্রজেক্ট','tools':'টুলস','reports':'রিপোর্ট','settings':'সেটিংস','welcome':'AI দিয়ে নির্মাণ পরিকল্পনা করুন','quick':'দ্রুত টুলস','newProject':'নতুন প্রজেক্ট','calculator':'কংক্রিট ক্যালকুলেটর','converter':'একক রূপান্তর','land':'জমি মাপার ডেমো','design':'বাড়ির ডিজাইন স্টুডিও','estimate':'খরচের হিসাব','language':'অ্যাপের ভাষা','save':'সংরক্ষণ','length':'দৈর্ঘ্য (মিটার)','width':'প্রস্থ (মিটার)','thickness':'পুরুত্ব (মিটার)','calculate':'হিসাব করুন','result':'ফলাফল','name':'প্রজেক্টের নাম','create':'প্রজেক্ট তৈরি','noProjects':'এখনো কোনো প্রজেক্ট নেই','demo':'ডেমো প্রিভিউ','notice':'এটি প্রাথমিক ডেমো। সব মাপ ও কাঠামোগত নকশা যোগ্য প্রকৌশলী দিয়ে যাচাই করুন।','floors':'তলার সংখ্যা','generate':'ডিজাইন প্রিভিউ','mapping':'ক্যামেরা ম্যাপিং প্রিভিউ','capture':'রেফারেন্স পয়েন্ট নিন','report':'প্রজেক্ট রিপোর্ট','total':'আনুমানিক মোট','materials':'উপকরণের সারাংশ','area':'ক্ষেত্রফল','volume':'আয়তন'},
    'hi': {'home':'होम','projects':'परियोजनाएँ','tools':'टूल्स','reports':'रिपोर्ट','settings':'सेटिंग्स','welcome':'AI के साथ बेहतर निर्माण','quick':'त्वरित टूल्स','newProject':'नई परियोजना','calculator':'कंक्रीट कैलकुलेटर','converter':'इकाई बदलें','land':'भूमि मापन डेमो','design':'घर डिज़ाइन स्टूडियो','estimate':'लागत अनुमान','language':'ऐप की भाषा','save':'सहेजें','length':'लंबाई (m)','width':'चौड़ाई (m)','thickness':'मोटाई (m)','calculate':'गणना करें','result':'परिणाम','name':'परियोजना का नाम','create':'परियोजना बनाएँ','noProjects':'अभी कोई परियोजना नहीं','demo':'डेमो प्रीव्यू','notice':'यह प्रारंभिक डेमो है। माप और संरचनात्मक डिज़ाइन योग्य इंजीनियर से जाँचें।','floors':'मंज़िलों की संख्या','generate':'डिज़ाइन प्रीव्यू','mapping':'कैमरा मैपिंग प्रीव्यू','capture':'संदर्भ बिंदु लें','report':'परियोजना रिपोर्ट','total':'अनुमानित कुल','materials':'सामग्री सारांश','area':'क्षेत्रफल','volume':'आयतन'}
  };
  return map[code]?[key] ?? map['en']![key] ?? key;
}

class DemoShell extends StatefulWidget {
  final String locale;
  final ValueChanged<String> onLocale;
  const DemoShell({super.key, required this.locale, required this.onLocale});
  @override
  State<DemoShell> createState() => _DemoShellState();
}
class _DemoShellState extends State<DemoShell> {
  int tab=0;
  final List<String> projects=[];
  String t(String k)=>tr(widget.locale,k);
  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(t:t, go:(i)=>setState(()=>tab=i), projects:projects),
      ProjectsPage(t:t, projects:projects, add:(v)=>setState(()=>projects.add(v))),
      ToolsPage(t:t),
      ReportsPage(t:t, projects:projects),
      SettingsPage(t:t, locale:widget.locale, onLocale:widget.onLocale),
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('BuildMaster AI'), actions:[Padding(padding:const EdgeInsets.only(right:16), child: Center(child: Text(widget.locale.toUpperCase(),style:const TextStyle(fontWeight:FontWeight.bold))))]),
      body: pages[tab],
      bottomNavigationBar: NavigationBar(selectedIndex:tab,onDestinationSelected:(i)=>setState(()=>tab=i), destinations:[
        NavigationDestination(icon:const Icon(Icons.home_outlined),label:t('home')),
        NavigationDestination(icon:const Icon(Icons.folder_open),label:t('projects')),
        NavigationDestination(icon:const Icon(Icons.construction),label:t('tools')),
        NavigationDestination(icon:const Icon(Icons.assessment_outlined),label:t('reports')),
        NavigationDestination(icon:const Icon(Icons.settings_outlined),label:t('settings')),
      ]),
    );
  }
}

class HomePage extends StatelessWidget {
  final String Function(String) t; final ValueChanged<int> go; final List<String> projects;
  const HomePage({super.key,required this.t,required this.go,required this.projects});
  @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(16),children:[
    Container(padding:const EdgeInsets.all(20),decoration:BoxDecoration(borderRadius:BorderRadius.circular(22),gradient:const LinearGradient(colors:[Color(0xff176b58),Color(0xff35a887)])),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text(t('welcome'),style:const TextStyle(color:Colors.white,fontSize:23,fontWeight:FontWeight.bold)),
      const SizedBox(height:8),Text('${projects.length} ${t('projects').toLowerCase()}',style:const TextStyle(color:Colors.white70)),
      const SizedBox(height:16),const Chip(label:Text('BUILD • PLAN • ESTIMATE'))
    ])),
    const SizedBox(height:20),Text(t('quick'),style:Theme.of(context).textTheme.titleLarge),
    const SizedBox(height:10),GridView.count(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),crossAxisCount:2,crossAxisSpacing:10,mainAxisSpacing:10,childAspectRatio:1.25,children:[
      _tile(context,Icons.calculate,t('calculator'),()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>CalculatorPage(t:t)))),
      _tile(context,Icons.straighten,t('converter'),()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ConverterPage(t:t)))),
      _tile(context,Icons.camera_alt_outlined,t('land'),()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>MappingPage(t:t)))),
      _tile(context,Icons.architecture,t('design'),()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>DesignPage(t:t)))),
      _tile(context,Icons.price_change_outlined,t('estimate'),()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>EstimatePage(t:t)))),
      _tile(context,Icons.add_box_outlined,t('newProject'),()=>go(1)),
    ]),
    const SizedBox(height:18),_notice(t('notice')),
  ]);
  Widget _tile(BuildContext c,IconData icon,String title,VoidCallback tap)=>Card(child:InkWell(borderRadius:BorderRadius.circular(14),onTap:tap,child:Padding(padding:const EdgeInsets.all(14),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Icon(icon,size:30,color:Theme.of(c).colorScheme.primary),const SizedBox(height:8),Text(title,textAlign:TextAlign.center,style:const TextStyle(fontWeight:FontWeight.w600))]))));
}

class ProjectsPage extends StatefulWidget {
 final String Function(String) t; final List<String> projects; final ValueChanged<String> add;
 const ProjectsPage({super.key,required this.t,required this.projects,required this.add});
 @override State<ProjectsPage> createState()=>_ProjectsPageState();
}
class _ProjectsPageState extends State<ProjectsPage>{
 final controller=TextEditingController();
 @override Widget build(BuildContext context)=>Padding(padding:const EdgeInsets.all(16),child:Column(children:[
  TextField(controller:controller,decoration:InputDecoration(labelText:widget.t('name'),border:const OutlineInputBorder(),prefixIcon:const Icon(Icons.edit))),
  const SizedBox(height:8),FilledButton.icon(onPressed:(){if(controller.text.trim().isNotEmpty){widget.add(controller.text.trim());controller.clear();setState((){});}},icon:const Icon(Icons.add),label:Text(widget.t('create'))),
  const SizedBox(height:16),Expanded(child:widget.projects.isEmpty?Center(child:Text(widget.t('noProjects'))):ListView(children:widget.projects.map((p)=>Card(child:ListTile(leading:const Icon(Icons.apartment),title:Text(p),subtitle:const Text('Draft • Demo project'),trailing:const Icon(Icons.chevron_right)))).toList()))
 ]));
}

class ToolsPage extends StatelessWidget{
 final String Function(String)t; const ToolsPage({super.key,required this.t});
 @override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(12),children:[
  _tool(c,Icons.calculate,t('calculator'),()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>CalculatorPage(t:t)))),
  _tool(c,Icons.swap_horiz,t('converter'),()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>ConverterPage(t:t)))),
  _tool(c,Icons.camera_alt,t('mapping'),()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>MappingPage(t:t)))),
  _tool(c,Icons.view_in_ar,t('design'),()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>DesignPage(t:t)))),
  _tool(c,Icons.payments,t('estimate'),()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>EstimatePage(t:t)))),
 ]);
 Widget _tool(BuildContext c,IconData i,String s,VoidCallback f)=>Card(child:ListTile(leading:Icon(i),title:Text(s),trailing:const Icon(Icons.arrow_forward_ios,size:16),onTap:f));
}

class CalculatorPage extends StatefulWidget{final String Function(String)t;const CalculatorPage({super.key,required this.t});@override State<CalculatorPage>createState()=>_CalculatorPageState();}
class _CalculatorPageState extends State<CalculatorPage>{
 final a=TextEditingController(text:'5'),b=TextEditingController(text:'4'),d=TextEditingController(text:'0.1');double? result;
 @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:Text(widget.t('calculator'))),body:ListView(padding:const EdgeInsets.all(16),children:[
  _field(a,widget.t('length')),_field(b,widget.t('width')),_field(d,widget.t('thickness')),
  FilledButton(onPressed:(){setState(()=>result=(double.tryParse(a.text)??0)*(double.tryParse(b.text)??0)*(double.tryParse(d.text)??0));},child:Text(widget.t('calculate'))),
  if(result!=null)Card(child:Padding(padding:const EdgeInsets.all(18),child:Text('${widget.t('result')}: ${result!.toStringAsFixed(3)} m³  •  ${(result!*35.3147).toStringAsFixed(2)} CFT',style:const TextStyle(fontSize:18,fontWeight:FontWeight.bold))))
 ]));
 Widget _field(TextEditingController c,String label)=>Padding(padding:const EdgeInsets.only(bottom:12),child:TextField(controller:c,keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:InputDecoration(labelText:label,border:const OutlineInputBorder())));
}

class ConverterPage extends StatefulWidget{final String Function(String)t;const ConverterPage({super.key,required this.t});@override State<ConverterPage>createState()=>_ConverterPageState();}
class _ConverterPageState extends State<ConverterPage>{final c=TextEditingController(text:'1');String unit='m → ft';double? out;
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text(widget.t('converter'))),body:Padding(padding:const EdgeInsets.all(16),child:Column(children:[
 TextField(controller:c,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Value',border:OutlineInputBorder())),
 const SizedBox(height:12),DropdownButtonFormField<String>(value:unit,items:['m → ft','ft → m','inch → mm','CFT → m³','m³ → CFT','sq ft → sq m'].map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),onChanged:(v)=>setState(()=>unit=v!),decoration:const InputDecoration(border:OutlineInputBorder())),
 const SizedBox(height:12),FilledButton(onPressed:(){final v=double.tryParse(c.text)??0;setState(()=>out=switch(unit){'m → ft'=>v*3.28084,'ft → m'=>v/3.28084,'inch → mm'=>v*25.4,'CFT → m³'=>v/35.3147,'m³ → CFT'=>v*35.3147,_=>v*0.092903});},child:Text(widget.t('calculate'))),
 if(out!=null)Text('${widget.t('result')}: ${out!.toStringAsFixed(4)}',style:Theme.of(context).textTheme.headlineSmall)
 ])));
}

class MappingPage extends StatefulWidget{final String Function(String)t;const MappingPage({super.key,required this.t});@override State<MappingPage>createState()=>_MappingPageState();}
class _MappingPageState extends State<MappingPage>{int points=0;
 @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:Text(widget.t('land'))),body:Padding(padding:const EdgeInsets.all(16),child:Column(children:[
  Container(height:230,width:double.infinity,decoration:BoxDecoration(color:Colors.blueGrey.shade50,borderRadius:BorderRadius.circular(18),border:Border.all(color:Colors.teal)),child:Stack(children:[
   const Center(child:Icon(Icons.map_outlined,size:90,color:Colors.teal)),Positioned(left:20,top:20,child:Chip(label:Text('${widget.t('demo')} • CAMERA'))),
   Positioned(right:30,bottom:30,child:Text('P1 ───── P2\\n│             │\\nP4 ───── P3',style:const TextStyle(fontSize:18,fontWeight:FontWeight.bold,color:Colors.teal)))
  ])),
  const SizedBox(height:12),Text('${widget.t('capture')}: $points'),FilledButton.icon(onPressed:()=>setState(()=>points++),icon:const Icon(Icons.add_a_photo),label:Text(widget.t('capture'))),
  const SizedBox(height:12),const Text('Demo only: camera-based measurements need scale calibration and known reference dimensions. For legal boundary survey, use a qualified surveyor.')
 ])));
}

class DesignPage extends StatefulWidget{final String Function(String)t;const DesignPage({super.key,required this.t});@override State<DesignPage>createState()=>_DesignPageState();}
class _DesignPageState extends State<DesignPage>{int floors=1;bool show3d=false;
 @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:Text(widget.t('design'))),body:ListView(padding:const EdgeInsets.all(16),children:[
 DropdownButtonFormField<int>(value:floors,decoration:InputDecoration(labelText:widget.t('floors'),border:const OutlineInputBorder()),items:[1,2,3].map((x)=>DropdownMenuItem(value:x,child:Text('$x'))).toList(),onChanged:(v)=>setState(()=>floors=v!)),
 const SizedBox(height:12),SegmentedButton<bool>(segments:const [ButtonSegment(value:false,label:Text('2D')),ButtonSegment(value:true,label:Text('3D'))],selected:{show3d},onSelectionChanged:(v)=>setState(()=>show3d=v.first)),
 const SizedBox(height:16),Container(height:270,decoration:BoxDecoration(color:const Color(0xffedf4f1),borderRadius:BorderRadius.circular(16)),child:Center(child:show3d?_building3d():_plan2d())),
 FilledButton(onPressed:()=>ScaffoldMessenger.of(c).showSnackBar(const SnackBar(content:Text('Demo design preview generated. Engineer review required.'))),child:Text(widget.t('generate'))),
 _notice(widget.t('notice'))
 ]));
 Widget _plan2d()=>Column(mainAxisAlignment:MainAxisAlignment.center,children:List.generate(floors,(i)=>Container(width:190,height:65,margin:const EdgeInsets.all(4),decoration:BoxDecoration(border:Border.all(color:Colors.teal,width:2),color:Colors.white),child:Center(child:Text('FLOOR ${i+1} • ROOM PLAN')))));
 Widget _building3d()=>Column(mainAxisAlignment:MainAxisAlignment.center,children:[Icon(Icons.apartment,size:90,color:Colors.teal),Text('$floors-storey massing preview',style:const TextStyle(fontWeight:FontWeight.bold))]);
}

class EstimatePage extends StatefulWidget{final String Function(String)t;const EstimatePage({super.key,required this.t});@override State<EstimatePage>createState()=>_EstimatePageState();}
class _EstimatePageState extends State<EstimatePage>{final area=TextEditingController(text:'1200');double? total;
 @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:Text(widget.t('estimate'))),body:Padding(padding:const EdgeInsets.all(16),child:Column(children:[
 TextField(controller:area,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Built-up area (sq ft)',border:OutlineInputBorder())),
 const SizedBox(height:12),FilledButton(onPressed:(){setState(()=>total=(double.tryParse(area.text)??0)*1800);},child:Text(widget.t('calculate'))),
 if(total!=null)Card(child:ListTile(title:Text(widget.t('total')),subtitle:Text('৳ ${total!.toStringAsFixed(0)} (illustrative rate)'),leading:const Icon(Icons.currency_exchange))),
 Text(widget.t('materials')),const ListTile(title:Text('Cement / Sand / Aggregate / Steel'),subtitle:Text('Indicative quantities only'))
 ])));
}

class ReportsPage extends StatelessWidget{final String Function(String)t;final List<String>projects;const ReportsPage({super.key,required this.t,required this.projects});
 @override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(16),children:[
  Text(t('report'),style:Theme.of(c).textTheme.headlineSmall),Card(child:ListTile(leading:const Icon(Icons.folder),title:Text(t('projects')),trailing:Text('${projects.length}'))),
  Card(child:ListTile(leading:const Icon(Icons.summarize),title:Text(t('materials')),subtitle:const Text('Sample report • PDF export is planned'))),
  FilledButton.icon(onPressed:()=>ScaffoldMessenger.of(c).showSnackBar(const SnackBar(content:Text('PDF export is a planned demo feature.'))),icon:const Icon(Icons.picture_as_pdf),label:const Text('Preview PDF report'))
 ]);
}

class SettingsPage extends StatelessWidget{final String locale;final ValueChanged<String>onLocale;final String Function(String)t;SettingsPage({super.key,required this.locale,required this.onLocale}):t=(k)=>tr(locale,k);
 @override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(16),children:[
  Text(t('language'),style:Theme.of(c).textTheme.titleLarge),const SizedBox(height:8),
  ...languages.entries.map((e)=>RadioListTile<String>(value:e.value,groupValue:locale,title:Text(e.key),onChanged:(v)=>onLocale(v!))),
  const Divider(),const ListTile(leading:Icon(Icons.info_outline),title:Text('BuildMaster AI Demo'),subtitle:Text('Prototype • Not for construction approval'))
 ]);
}

Widget _notice(String text)=>Container(padding:const EdgeInsets.all(12),decoration:BoxDecoration(color:Colors.amber.shade50,borderRadius:BorderRadius.circular(12)),child:Row(crossAxisAlignment:CrossAxisAlignment.start,children:[const Icon(Icons.info_outline,color:Colors.orange),const SizedBox(width:8),Expanded(child:Text(text,style:const TextStyle(fontSize:12))) ]));
